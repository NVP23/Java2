package th02553_126_06_assignment;

/**
 *
 * @author ACER
 */
public class Laptop extends MayTinh {

    private String hang;
    private String mauSac;

    public Laptop(String hang, String mauSac, String ma, String ten, float gia) {
        super(ma, ten, gia);
        this.hang = hang;
        this.mauSac = mauSac;
    }

    public Laptop() {
    }

    public String getHang() {
        return hang;
    }

    public void setHang(String hang) {
        this.hang = hang;
    }

    public String getMauSac() {
        return mauSac;
    }

    public void setMauSac(String mauSac) {
        this.mauSac = mauSac;
    }

    public void inThongTin() {
        System.out.println("hang: " + this.hang);
        System.out.println("mauSac: " + this.mauSac);
        System.out.println("ma: " + super.getMa());
        System.out.println("ten: " + super.getTen());
        System.out.println("gia: " + super.getGia());
    }

}
