package th02553_126_06_assignment;

/**
 *
 * @author ACER
 */
public class MayTinh {

    private String ma;
    private String ten;
    private float gia;

    public MayTinh() {
    }

    public MayTinh(String ma, String ten, float gia) {
        this.ma = ma;
        this.ten = ten;
        this.gia = gia;
    }

    public String getMa() {
        return ma;
    }

    public void setMa(String ma) {
        this.ma = ma;
    }

    public String getTen() {
        return ten;
    }

    public void setTen(String ten) {
        this.ten = ten;
    }

    public float getGia() {
        return gia;
    }

    public void setGia(float gia) {
        this.gia = gia;
    }

//    public void inThongTin(){
//        System.out.println("ma: " + this.ma);
//        System.out.println("ten: " + this.ten);
//        System.out.println("gia: " + this.gia);
//    }
    @Override
    public String toString() {
        return "MayTinh{" + "ma=" + ma + ", ten=" + ten + ", gia=" + gia + '}';
    }

}
