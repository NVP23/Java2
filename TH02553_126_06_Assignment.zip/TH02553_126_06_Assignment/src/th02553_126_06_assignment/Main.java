package th02553_126_06_assignment;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author ACER
 */
public class Main {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ArrayList<MayTinh> arr = new ArrayList<>();
        MayTinhService mt = new MayTinhService();

        int ch;

        do {
            System.out.println("+---------------- MENU ----------------+");
            System.out.println("1. Chuc nang 1");
            System.out.println("2. Chuc nang 2");
            System.out.println("3. Chuc nang 3");
            System.out.println("4. Chuc nang 4");
            System.out.println("5. Chuc nang 5");
            System.out.println("6. Chuc nang 6");
            System.out.println("0. Thoát");
            System.out.println("+--------------------------------------+");
            System.out.print("Moi nhap: ");
            ch = Integer.parseInt(sc.nextLine());

            switch (ch) {
                case 1 -> {
                    mt.yeuCau1(arr);
                }
                case 2 -> {
                    mt.yeuCau2(arr);
                }
                case 3 -> {
                    System.out.print("Nhap ten: ");
                    String name = sc.nextLine();
                    System.out.print("Nhap min: ");
                    float min = Float.parseFloat(sc.nextLine());
                    System.out.print("Nhap max: ");
                    float max = Float.parseFloat(sc.nextLine());

                    ArrayList<MayTinh> arrMoi = mt.yeuCau3(arr, name, min, max);

                    for (MayTinh mayTinh : arrMoi) {
                        System.out.println(mayTinh);
                    }
                }
                case 4 -> {
                    mt.yeuCau4(arr);
                    System.out.println("Danh sach cua ban sau khi xoa: ");
                    mt.yeuCau2(arr);
                }
                case 5 -> {
                    mt.yeuCau5(arr);
                }
                case 6 -> {
                    Laptop lap = new Laptop("Acer", "Den", "P123", "MayTinh1", 10000);

                    lap.inThongTin();
                }
                case 0 -> {
                    System.out.println("Da Thoat Chuong Trinh!\n");
                }

                default ->
                    System.out.println("Vui long chon dung lua chon!\n");
            }
        } while (ch != 0);

    }

}
