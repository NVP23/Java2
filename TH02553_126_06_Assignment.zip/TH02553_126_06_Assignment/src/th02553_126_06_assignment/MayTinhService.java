package th02553_126_06_assignment;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author ACER
 */
public class MayTinhService {

    Scanner sc = new Scanner(System.in);
    MayTinh o;

    public void yeuCau1(ArrayList<MayTinh> arr) {
        int chon;
        do {

            System.out.print("Nhap ma: ");
            String ma = sc.nextLine();
            System.out.print("Nhap ten: ");
            String ten = sc.nextLine();
            System.out.print("Nhap gia: ");
            float gia = Integer.parseInt(sc.nextLine());
            o = new MayTinh(ma, ten, gia);
            arr.add(o);
            System.out.println("Da them may tinh!");
            System.out.print("Ban co muon nhap tiep ko? (1 - Co, 0 - Khong): ");
            chon = Integer.parseInt(sc.nextLine());
        } while (chon != 0);
    }

    public void yeuCau2(ArrayList<MayTinh> arr) {
        if (arr.isEmpty()) {
            System.out.println("Danh sach rong");
        } else {
            for (MayTinh mayTinh : arr) {
                System.out.println(mayTinh);
            }
        }
    }

    public ArrayList<MayTinh> yeuCau3(ArrayList<MayTinh> arr, String name, float min, float max) {
        ArrayList<MayTinh> listMoi = new ArrayList<>();
        for (MayTinh mayTinh : arr) {
            if (mayTinh.getTen().contains(name) && mayTinh.getGia() > min && max > mayTinh.getGia()) {
                listMoi.add(mayTinh);
            }
        }
   
        return listMoi;
    }

    public void yeuCau4(ArrayList<MayTinh> arr) {
        System.out.print("Nhap ma: ");
        String ma = sc.nextLine();
        int a = 0;
        for (MayTinh mayTinh : arr) {
            if (mayTinh.getMa().equals(ma)) {
                a++;
            }
        }
        if (a > 0) {
            //ten -> (ten tung thuoc tinh -> dieu kien xoa)
            arr.removeIf(ob -> ob.getMa().equals(ma));
            System.out.println("Da Xoa!");
        } else {
            System.out.println("Ko co de xoa");
        }
    }

    public void yeuCau5(ArrayList<MayTinh> arr) {
        float max = Float.MIN_VALUE;

        for (MayTinh mayTinh : arr) {
            if (mayTinh.getGia() > max) {
                max = mayTinh.getGia();
            }
        }
        int dem = 0;
        System.out.println("May tinh co gia cao nhat la:");
        for (MayTinh mayTinh : arr) {
            if (mayTinh.getGia() == max) {
                System.out.println(mayTinh);
                dem++;
            }
        }
        if (dem == 0) {
            System.out.println("Khong co may tinh gia cao nhat");
        }
    }

    public void yeuCau6() {

    }

}
